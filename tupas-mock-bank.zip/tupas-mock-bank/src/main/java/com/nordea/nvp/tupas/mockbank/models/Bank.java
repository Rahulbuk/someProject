package com.nordea.nvp.tupas.mockbank.models;

public class Bank {

    String bankid="";
    String bankVersion="";
    String bankSecretkey="";
    String algo="";
    String algoVersion="";


}
